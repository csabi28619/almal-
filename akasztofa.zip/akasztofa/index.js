let buttonHolder = document.getElementById("buttonHolder")

let letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

let word = "PACAL"

let mistake = 0 //hibaszámláló

for(let i = 0 /* ciklusváltozó */; i < letters.length /* ciklusfeltétel */; i +=1 /* léptető utasítás */){
    buttonHolder.innerHTML += 
    '<button onclick="clicked(this)">'
    +letters[i]+
    '</button>'
}

for (let j = 0; j < word.length; j++){
document.getElementById("status").innerText += "_"

}

function clicked(button){
    
button.disabled = true

let letter = button.innerText

if(word.includes(letter)){

    
    let status = document.getElementById
    ("status").innerText

let newStatus = ""

for(let i = 0; i < word.length; i++){
if(word[i] == letter){
newStatus += letter
}
else{
    newStatus += status[i]
}
}
document.getElementById("status").innerText = newStatus

if(newStatus == word){alert("NYERTÉL")
buttonHolder.innerHTML = ""
}

}else{
    mistake++
        
document.getElementById("imageHolder").innerHTML = `<img src="${mistake}.png" width="50%">`
if(mistake ==11){
alert("GAME OVER")
buttonHolder.innerHTML = ""

}
    }
}
